/*
SQLyog 企业版 - MySQL GUI v7.14 
MySQL - 5.1.36-community : Database - model_web
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`model_web` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `model_web`;

/*Table structure for table `t_node_task` */

DROP TABLE IF EXISTS `t_node_task`;

CREATE TABLE `t_node_task` (
  `id` varchar(32) NOT NULL,
  `send_node_id` varchar(32) DEFAULT NULL,
  `task_id` varchar(32) DEFAULT NULL,
  `receive_node_id` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `t_node_task` */

insert  into `t_node_task`(`id`,`send_node_id`,`task_id`,`receive_node_id`) values ('60352130','87294626','60352130','87294626');

/*Table structure for table `t_nodes` */

DROP TABLE IF EXISTS `t_nodes`;

CREATE TABLE `t_nodes` (
  `nodes_id` varchar(32) NOT NULL,
  `nodes_name` varchar(32) DEFAULT NULL,
  `nodes_ip` varchar(16) DEFAULT NULL,
  `nodes_serviceport` varchar(16) DEFAULT NULL,
  `nodes_servicename` varchar(32) DEFAULT NULL,
  `nodes_filepath` varchar(64) DEFAULT NULL,
  `nodes_savepath` varchar(64) DEFAULT NULL,
  `nodes_status` varchar(2) DEFAULT NULL,
  `nodes_type` varchar(2) DEFAULT NULL,
  `nodes_des` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`nodes_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `t_nodes` */

insert  into `t_nodes`(`nodes_id`,`nodes_name`,`nodes_ip`,`nodes_serviceport`,`nodes_servicename`,`nodes_filepath`,`nodes_savepath`,`nodes_status`,`nodes_type`,`nodes_des`) values ('08425763','182','192.168.110.182','6666','pointManager','D:\\file\\','D:\\temps\\','0','2',''),('37250589','1344','192.168.110.134','6666','pointManager','/home/file/','/home/temp/','0','2',''),('59801963','1','192.168.110.1','6666','pointManager','D:\\file\\','D:\\log\\','0','2',''),('87294626','Dell','172.20.10.2','6666','pointManager','D:\\file\\','D:\\log\\','0','2','');

/*Table structure for table `t_sys_menu` */

DROP TABLE IF EXISTS `t_sys_menu`;

CREATE TABLE `t_sys_menu` (
  `menu_icon` varchar(20) DEFAULT NULL,
  `id` varchar(32) NOT NULL,
  `menu_code` varchar(16) DEFAULT NULL,
  `menu_name` varchar(50) DEFAULT NULL,
  `url` varchar(500) DEFAULT NULL,
  `des` varchar(100) DEFAULT NULL,
  `pid` varchar(32) DEFAULT NULL,
  `state` varchar(2) DEFAULT NULL,
  `level` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `t_sys_menu` */

insert  into `t_sys_menu`(`menu_icon`,`id`,`menu_code`,`menu_name`,`url`,`des`,`pid`,`state`,`level`) values ('icon-sys','101','M01','系统管理','','','','0','1'),('icon-users','102','M0101','用户管理','User/index','','101','0','2'),('icon-page','103','M0102','菜单管理','Menu/index','','101','0','2'),('icon-role','104','M0103','角色管理','Role/index','','101','0','2');

/*Table structure for table `t_sys_nodes_config` */

DROP TABLE IF EXISTS `t_sys_nodes_config`;

CREATE TABLE `t_sys_nodes_config` (
  `nodesconfigid` varchar(32) NOT NULL,
  `nodesconfigname` varchar(32) DEFAULT NULL,
  `nodesconfigserviceip` varchar(16) DEFAULT NULL,
  `nodesconfigserviceport` varchar(16) DEFAULT NULL,
  `nodesconfigservicename` varchar(32) DEFAULT NULL,
  `nodesconfigfilepath` varchar(64) DEFAULT NULL,
  `nodesconfigsavepath` varchar(64) DEFAULT NULL,
  `nodesconfigdes` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`nodesconfigid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `t_sys_nodes_config` */

insert  into `t_sys_nodes_config`(`nodesconfigid`,`nodesconfigname`,`nodesconfigserviceip`,`nodesconfigserviceport`,`nodesconfigservicename`,`nodesconfigfilepath`,`nodesconfigsavepath`,`nodesconfigdes`) values ('99142800','1','Dell','2','3','4','5','1');

/*Table structure for table `t_sys_role` */

DROP TABLE IF EXISTS `t_sys_role`;

CREATE TABLE `t_sys_role` (
  `id` varchar(32) NOT NULL,
  `role_code` varchar(16) DEFAULT NULL,
  `role_name` varchar(50) DEFAULT NULL,
  `des` varchar(200) DEFAULT NULL,
  `state` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `t_sys_role` */

insert  into `t_sys_role`(`id`,`role_code`,`role_name`,`des`,`state`) values ('1','r01','king',NULL,'1');

/*Table structure for table `t_sys_role_menu` */

DROP TABLE IF EXISTS `t_sys_role_menu`;

CREATE TABLE `t_sys_role_menu` (
  `id` varchar(32) NOT NULL,
  `role_id` varchar(32) DEFAULT NULL,
  `menu_id` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `t_sys_role_menu` */

insert  into `t_sys_role_menu`(`id`,`role_id`,`menu_id`) values ('00114348','1','102'),('1','1','21'),('13680963','1','104'),('18150125','1','101'),('2','1','22'),('3','1','211'),('4','1','212'),('5','1','221'),('56103871','1','103');

/*Table structure for table `t_sys_user` */

DROP TABLE IF EXISTS `t_sys_user`;

CREATE TABLE `t_sys_user` (
  `id` varchar(32) NOT NULL,
  `LOGINNAME` varchar(64) DEFAULT NULL,
  `LOGINPWD` varchar(64) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `state` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `t_sys_user` */

insert  into `t_sys_user`(`id`,`LOGINNAME`,`LOGINPWD`,`name`,`state`) values ('00899290','12','1','tunglogo','0'),('1','admin','1','admin','1'),('19156805','120','1','TUNGLOGO','0'),('2','pm','1','project_Manager','1'),('27505963','admin1','1','啊','0'),('3','tom','1','tommy','1'),('56812542','安安','1','啊','1');

/*Table structure for table `t_sys_user_role` */

DROP TABLE IF EXISTS `t_sys_user_role`;

CREATE TABLE `t_sys_user_role` (
  `id` varchar(32) NOT NULL,
  `user_id` varchar(32) DEFAULT NULL,
  `role_id` varchar(32) DEFAULT NULL,
  `user_type` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `t_sys_user_role` */

insert  into `t_sys_user_role`(`id`,`user_id`,`role_id`,`user_type`) values ('01399550','08683078','1',NULL),('04465534','05598800','1',NULL),('47757751','1','1',NULL),('88010542','08683078','1',NULL);

/*Table structure for table `t_task` */

DROP TABLE IF EXISTS `t_task`;

CREATE TABLE `t_task` (
  `task_id` varchar(32) NOT NULL,
  `task_name` varchar(32) DEFAULT NULL,
  `task_send_node` varchar(32) DEFAULT NULL,
  `task_receive_node` varchar(32) DEFAULT NULL,
  `task_encryption` varchar(32) DEFAULT NULL,
  `task_des` varchar(5000) DEFAULT NULL,
  PRIMARY KEY (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `t_task` */

insert  into `t_task`(`task_id`,`task_name`,`task_send_node`,`task_receive_node`,`task_encryption`,`task_des`) values ('60352130','dell','1','1','1','');

/*Table structure for table `t_task_timer` */

DROP TABLE IF EXISTS `t_task_timer`;

CREATE TABLE `t_task_timer` (
  `task_timer_id` varchar(32) NOT NULL,
  `task_id` varchar(32) NOT NULL,
  `task_name` varchar(32) DEFAULT NULL,
  `task_timer_type` varchar(32) DEFAULT NULL,
  `task_timer_second` varchar(32) DEFAULT NULL,
  `task_timer_min` varchar(32) DEFAULT NULL,
  `task_timer_day` varchar(32) DEFAULT NULL,
  `task_timer_week` varchar(32) DEFAULT NULL,
  `task_timer_month` varchar(32) DEFAULT NULL,
  `task_timer_hour` varchar(32) DEFAULT NULL,
  `task_timer_daytime` varchar(32) DEFAULT NULL,
  `task_timer_status` varchar(2) DEFAULT '0',
  PRIMARY KEY (`task_timer_id`,`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `t_task_timer` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
