function showMsg(a,b,c){//页面消息弹框a：标题  b：内容 c:类型（error,success,info,notice
	new PNotify({
        title: a,
        text: b,
        type: c,
        styling: 'bootstrap3'
    });
}
