package com.system.service;

import java.util.List;
import java.util.Map;

import com.base.tools.PageBean;
import com.system.domain.User;

public interface UserService {
	public User selectUserById(String userId);

	public User getByLoginame(String loginame);

	public List<User> queryAll(PageBean<User> dg, User user);

	public Integer getCount(User user);

	public void deleteUser(String[] ids);

	public void saveUser(User user);

	public void udpatePassword(String id, String password);

	public void saveRoleSelect(String userid, String ids);

	public List<Map<String, Object>> userRoleSelectTree(String userid);
}
