package com.system.service;

import java.util.List;
import java.util.Map;

import com.base.tools.PageBean;
import com.system.domain.Menu;
import com.system.domain.User;

import net.sf.json.JSONArray;

public interface MenuService {

	public JSONArray getMenuTree(User user);

	public List<Menu> queryMenuList(PageBean<Menu> dg, Menu menu);

	public void saveMenu(Menu menu);

	public void deleteMenu(String menuids) throws Exception;

	public Integer getCount();

	public List<Map<String, Object>> getMenuTreeAll();

}
