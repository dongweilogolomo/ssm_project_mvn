package com.system.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import com.base.tools.DateUtil;
import com.base.tools.PageBean;
import com.system.dao.MenuMapper;
import com.system.dao.RoleMapper;
import com.system.dao.RoleMenuMapper;
import com.system.dao.UserRoleMapper;
import com.system.domain.Menu;
import com.system.domain.Role;
import com.system.domain.RoleMenu;
import com.system.domain.UserRole;
import com.system.service.RoleService;

@Service
public class RoleServiceImpl implements RoleService {

	@Resource
	private UserRoleMapper userRoleMapper;

	@Resource
	private RoleMapper roleMapper;

	@Resource
	private RoleMenuMapper roleMenuMapper;

	@Resource
	private MenuMapper menuMapper;

	public List<Role> queryRoleByPage(PageBean<Role> dg, Role role) {
		return this.roleMapper.getAll(dg, role);
	}

	public Role getRoleById(String id) {
		return this.roleMapper.selectByPrimaryKey(id);
	}

	public void deleteRole(String ids) throws Exception {
		String roleids = "";
		String[] rids = ids.split(",");
		for (String id : rids) {
			roleids += "'" + id + "',";
		}
		roleids = roleids.substring(0, roleids.length() - 1);
		// 校验有没有用户使用此角色
		List<UserRole> listcount = this.userRoleMapper.getByRoleIds(roleids);
		if (listcount != null && listcount.size() > 0) {
			throw new Exception("有角色被用户使用，如想删除此角色，先去掉用户关联的角色");
		}
		String[] idlist = ids.split(",");
		for (String id : idlist) {
			this.roleMapper.deleteByPrimaryKey(id);
		}
	}

	public void saveRole(Role role) {
		if (StringUtils.isNotBlank(role.getId())) {
			this.roleMapper.updateByPrimaryKeySelective(role);
		} else {
			role.setId(DateUtil.getRandomNum());
			this.roleMapper.insertSelective(role);
		}
	}

	public List<Role> queryRoleByMenuIds(String menuIds) {
		List<String> mids = new ArrayList();
		for (String st : menuIds.split(",")) {
			mids.add(st);
		}
		return this.roleMapper.queryRoleByMenuIds(mids);
	}

	public List<Map<String, Object>> roleMenuSelectTree(String roleid) {
		List<Menu> menus = this.menuMapper.getAll(new PageBean(), new Menu());
		List<RoleMenu> roleMenuList = this.roleMenuMapper.getByRoleId(roleid);
		if (menus != null && menus.size() > 0) {
			Map<String, Map<String, Object>> tempMap = new HashMap<String, Map<String, Object>>();
			for (Menu menu : menus) {
				Map<String, Object> node = new HashMap<String, Object>();
				node.put("id", menu.getId());
				node.put("pid", menu.getPid());
				node.put("text", menu.getMenuName());
				for (RoleMenu roleMenu : roleMenuList) {
					if (roleMenu.getMenuId().equals(menu.getId())) {
						node.put("checked", true);
						break;
					}
				}
				tempMap.put(menu.getId(), node);
			}
			// 再次遍历数据，为每个数据设置children，children为list
			List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
			for (Menu menu : menus) {
				Map<String, Object> node = tempMap.get(menu.getId());
				// 用当前ID在tempMap中查找，找到了就是id的后代
				Map<String, Object> parent = (Map<String, Object>) tempMap
						.get(menu.getPid());
				if (parent != null) {
					@SuppressWarnings("rawtypes")
					List childrens = (List) parent.get("children");
					if (childrens == null) {
						childrens = new ArrayList<Map<String, Object>>();
						parent.put("children", childrens);
					}
					childrens.add(node);
				} else {
					list.add(node);
				}
			}
			return list;
		}
		return null;
	}

	public void saveMenuSelect(String roleid, String ids) {
		// 删除该用户拥有的角色
		this.roleMenuMapper.deleteByRoleId(roleid);
		if (StringUtils.isNotBlank(ids)) {
			String[] data = ids.split(",");
			for (String menuid : data) {
				RoleMenu rolemenu = new RoleMenu();
				rolemenu.setMenuId(menuid);
				rolemenu.setRoleId(roleid);
				rolemenu.setId(DateUtil.getRandomNum());
				this.roleMenuMapper.insertSelective(rolemenu);
			}
		}
	}

	public Integer getCount() {
		return this.roleMapper.getCount();
	}
}
