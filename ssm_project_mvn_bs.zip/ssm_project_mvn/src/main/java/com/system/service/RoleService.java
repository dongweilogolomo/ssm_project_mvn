package com.system.service;

import java.util.List;
import java.util.Map;

import com.base.tools.PageBean;
import com.system.domain.Role;

public interface RoleService {

	public List<Role> queryRoleByPage(PageBean<Role> dg, Role role);

	public Role getRoleById(String id);

	public void deleteRole(String ids) throws Exception;

	public void saveRole(Role role);

	public List<Role> queryRoleByMenuIds(String menuIds);

	public List<Map<String, Object>> roleMenuSelectTree(String roleid);

	public void saveMenuSelect(String roleid, String ids);

	public Integer getCount();

}
