package com.system.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import com.base.tools.DateUtil;
import com.base.tools.PageBean;
import com.system.dao.RoleMapper;
import com.system.dao.UserMapper;
import com.system.dao.UserRoleMapper;
import com.system.domain.Role;
import com.system.domain.User;
import com.system.domain.UserRole;
import com.system.service.UserService;

@Service
public class UserServiceImpl implements UserService {
	@Resource
	private UserMapper userMapper;

	@Resource
	private UserRoleMapper userRoleMapper;

	@Resource
	private RoleMapper roleMapper;

	public User selectUserById(String userId) {
		return userMapper.selectByPrimaryKey(userId);
	}

	public User getByLoginame(String loginame) {
		return this.userMapper.getByLoginame(loginame);
	}

	public List<User> queryAll(PageBean<User> dg, User user) {
		return this.userMapper.queryAll(dg, user);
	}

	public Integer getCount(User user) {
		return this.userMapper.getCount(user);
	}

	public void deleteUser(String[] ids) {
		List<String> mids = new ArrayList();
		for (String st : ids) {
			mids.add(st);
		}
		this.userMapper.deleteByPrimaryKey(mids);
	}

	public void saveUser(User user) {
		if (StringUtils.isNotBlank(user.getId())) {
			User u = this.selectUserById(user.getId());
			u.setLoginname(user.getLoginname());
			u.setName(user.getName());
			u.setState(user.getState());
			this.userMapper.updateByPrimaryKeySelective(u);
		} else {
			user.setLoginpwd("1");
			user.setId(DateUtil.getRandomNum());
			this.userMapper.insertSelective(user);
		}
	}

	public void udpatePassword(String id, String password) {
		User user = this.selectUserById(id);
		user.setLoginpwd(password);
		this.userMapper.updateByPrimaryKeySelective(user);
	}

	public void saveRoleSelect(String userid, String ids) {
		this.userRoleMapper.deleteByUserId(userid);
		if (StringUtils.isNotBlank(ids)) {
			String[] array = ids.split(",");
			for (String roleid : array) {
				UserRole userRole = new UserRole();
				userRole.setId(DateUtil.getRandomNum());
				userRole.setRoleId(roleid);
				userRole.setUserId(userid);
				this.userRoleMapper.insertSelective(userRole);
			}
		}
	}

	public List<Map<String, Object>> userRoleSelectTree(String userid) {
		List<Role> roles = this.roleMapper.getAll(new PageBean(), new Role());
		List<UserRole> userRoleList = this.userRoleMapper.getByUserId(userid);
		if (roles != null && roles.size() > 0) {
			List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
			for (Role role : roles) {
				Map<String, Object> node = new HashMap<String, Object>();
				node.put("id", role.getId());
				node.put("text", role.getRoleName());
				for (UserRole userRole : userRoleList) {
					if (userRole.getRoleId().equals(role.getId())) {
						node.put("checked", true);
						break;
					}
				}
				list.add(node);
			}
			return list;
		}
		return null;
	}

}
