package com.system.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import com.base.tools.DateUtil;
import com.base.tools.PageBean;
import com.system.dao.MenuMapper;
import com.system.dao.RoleMapper;
import com.system.domain.Menu;
import com.system.domain.Role;
import com.system.domain.User;
import com.system.service.MenuService;

import net.sf.json.JSONArray;

@Service
public class MenuServiceImpl implements MenuService {

	@Resource
	private MenuMapper menuMapper;
	@Resource
	private RoleMapper roleMapper;

	/**
	 * 获取用户对应菜单
	 * 
	 * @param user
	 * @return
	 */
	public JSONArray getMenuTree(User user) {
		JSONArray json = new JSONArray();
		List<Menu> menus = new ArrayList<Menu>();
		Map<String, Map<String, Object>> tempMap = new HashMap<String, Map<String, Object>>();
		if(user != null) {
			menus = this.menuMapper.getByUserId(user.getId());
			if (menus != null && menus.size() > 0) {
				for (Menu menu : menus) {
					Map<String, Object> node = new HashMap<String, Object>();
					node.put("menuid", menu.getId());
					node.put("menupid", menu.getPid());
					node.put("level", menu.getLevel());
					if(StringUtils.isNotBlank(menu.getMenuIcon()))
						node.put("icon", menu.getMenuIcon());
					node.put("menuname", menu.getMenuName());
					if(StringUtils.isNotBlank(menu.getUrl()))
						node.put("url", menu.getUrl());
					node.put("menus", new ArrayList<>());
					tempMap.put(menu.getId(), node);
				}
				for (Menu menu : menus) {
					Map<String, Object> node = tempMap.get(menu.getId());
					// 用当前ID在tempMap中查找，找到了就是id的后代
					Map<String, Object> parent = (Map<String, Object>) tempMap
							.get(menu.getPid());
					if (parent != null) {
						List childrens = (List) parent.get("menus");
						if (childrens == null) {
							childrens = new ArrayList<Map<String, Object>>();
							parent.put("menus", childrens);
						}
						childrens.add(node);
					} else {
						json.add(node);
					}
				}
			}
		}
		return json;
	}
	
	public List<Map<String, Object>> getMenuTreeAll(){
		List<Menu> menus = this.menuMapper.getAll(new PageBean<Menu>(), new Menu());
		Map<String, Map<String, Object>> tempMap = new HashMap<String, Map<String, Object>>();
		// 再次遍历数据，为每个数据设置children，children为list
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		if(menus != null && menus.size() > 0){
			for (Menu menu : menus) {
				ArrayList<String> tags = new ArrayList<String>();
				tags.add("菜单列表");
				Map<String, Object> node = new HashMap<String, Object>();
				node.put("id", menu.getId());
				node.put("pid", menu.getPid());
				node.put("code", menu.getMenuCode());
				node.put("text", menu.getMenuName());
				node.put("href", menu.getUrl());
				node.put("des", menu.getDes());
				node.put("stat", menu.getState());
				node.put("tags", tags);
				tempMap.put(menu.getId(), node);
			}
			for (Menu menu : menus) {
				Map<String, Object> node = tempMap.get(menu.getId());
				// 用当前ID在tempMap中查找，找到了就是id的后代
				Map<String, Object> parent = (Map<String, Object>) tempMap.get(menu.getPid());
				if (parent != null) {
					List childrens = (List) parent.get("nodes");
					if (childrens == null) {
						childrens = new ArrayList<Map<String, Object>>();
						parent.put("nodes", childrens);
					}
					childrens.add(node);
				} else {
					list.add(node);
				}
			}
		}
		return list;
}

	/**
	 * 查询菜单列表
	 * 
	 * @param page
	 * @param rows
	 * @param id
	 * @return
	 */
	public List<Menu> queryMenuList(PageBean<Menu> dg, Menu menu) {
		return this.menuMapper.getAll(dg, menu);
	}

	/**
	 * 编辑菜单
	 */
	public void saveMenu(Menu menu) {
		if (StringUtils.isNotBlank(menu.getId())) {
			this.menuMapper.updateByPrimaryKeySelective(menu);
		} else {
			menu.setId(DateUtil.getRandomNum());
			if(StringUtils.isNotBlank(menu.getPid())) {
				Menu m = this.menuMapper.selectByPrimaryKey(menu.getPid());
				menu.setLevel(String.valueOf(Integer.valueOf(m.getLevel())+1));
			}else {
				menu.setLevel("1");
			}
			this.menuMapper.insertSelective(menu);
		}
	}

	/**
	 * 删除菜单
	 * 
	 * @param ids
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	public void deleteMenu(String menuids) throws Exception {
		String[] ids = menuids.split(",");
		List<String> mids = new ArrayList();
		for (String st : ids) {
			mids.add(st);
		}
		List<Role> roles = this.roleMapper.queryRoleByMenuIds(mids);
		if (roles != null && roles.size() > 0) {
			String rolename = "";
			for (Role role : roles) {
				rolename += role.getRoleName() + ",";
			}
			rolename = rolename.substring(0, rolename.length() - 1);
			throw new Exception("角色：" + rolename + "已使用菜单，如想删除此菜单，先去掉角色关联的菜单");
		} else {
			List<Menu> list = menuMapper.getByPids(mids);
			if (list.size() > 0) {
				throw new Exception("有子菜单的节点，不能删除");
			}
			this.menuMapper.deleteByPrimaryKey(mids);
		}
	}

	public Integer getCount() {
		return this.menuMapper.getCount();
	}
}
