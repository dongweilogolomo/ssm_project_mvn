package com.system.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.base.tools.DatatablesViewPage;
import com.base.tools.PageBean;
import com.system.domain.Menu;
import com.system.domain.User;
import com.system.service.MenuService;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

@Controller
@RequestMapping("/Menu")
public class MenuController {

	@Resource
	private MenuService menuService;

	/**
	 * 跳转至菜单管理页面
	 * 
	 * @return
	 */
	@RequestMapping(value = "/index")
	public String index() {
		return "/system/menu";
	}

	/**
	 * 获取全部菜单
	 * 
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/menutreeAll")
	@ResponseBody
	public List<Map<String, Object>> menutreeAll() {
		return menuService.getMenuTreeAll();
	}

	/**
	 * 菜单列表查询
	 * 
	 * @param request
	 * @param response
	 * @param dg
	 * @throws Exception
	 */
	@RequestMapping("/queryList")
	@ResponseBody
	public String queryList(HttpServletRequest request, HttpServletResponse response, PageBean<Menu> dg,Menu menu) {
		List<Menu> m = this.menuService.queryMenuList(dg,menu);
		DatatablesViewPage<Menu> view = new DatatablesViewPage<Menu>();
		view.setDraw(dg.getDraw());
		view.setData(m);
		view.setRecordsFiltered(this.menuService.getCount());
		view.setRecordsTotal(view.getRecordsFiltered());
		return JSONObject.fromObject(view).toString();
	}

	/**
	 * 编辑菜单
	 * 
	 * @return
	 */
	@RequestMapping(value = "/save")
	@ResponseBody
	public String save(Menu menu) {
		try {
			this.menuService.saveMenu(menu);
		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage();
		}
		return "";
	}

	/**
	 * 删除菜单
	 * 
	 * @param request
	 * @param response
	 * @param ids
	 * @return
	 */
	@RequestMapping(value = "/delete",produces={"text/html;charset=UTF-8;"})
	@ResponseBody
	public String delete(String ids) {
		try {
			this.menuService.deleteMenu(ids);
		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage();
		}
		return "";
	}

	/**
	 * 根据用户获取菜单
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/getMenuTree")
	@ResponseBody
	public JSONArray getMenuTree(HttpSession session) {
		User user = (User) session.getAttribute("user");
		return this.menuService.getMenuTree(user);
	}

}
