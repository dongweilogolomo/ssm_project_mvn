package com.system.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.system.domain.User;
import com.system.service.UserService;

@Controller
public class LoginController {
	@Resource
	private UserService userService;
	
	@RequestMapping("/login")  
    public String login(HttpSession session,String username,String password) throws Exception{
		User u = userService.getByLoginame(username);
		if(u != null && password.equals(u.getLoginpwd())){
			session.setAttribute("username",username);  
			session.setAttribute("user",u);  
			System.out.print("login---");
		    return "redirect:/main";  
	    }else{  
	        //登陆失败  
		  	System.out.print("login false---");
	        return "redirect:/";  
	    }   
    }  
	
	@RequestMapping(value="/logout")  
    public String logout(HttpSession session) throws Exception{  
        //清除Session  
        session.invalidate();  
        return "login";  
	}
	
	@RequestMapping(value="/")  
    public String index(HttpSession session) throws Exception{  
        return "login";  
	}

	@RequestMapping("/main")  
    public String main(){    
        return "main";  
    }  
	
	@RequestMapping("/base")  
    public String base(){    
        return "base";  
    }  
}
