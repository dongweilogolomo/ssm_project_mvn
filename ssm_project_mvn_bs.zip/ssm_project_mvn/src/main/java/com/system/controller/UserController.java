package com.system.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.base.tools.DatatablesViewPage;
import com.base.tools.PageBean;
import com.system.domain.User;
import com.system.service.UserService;

import net.sf.json.JSONObject;

@Controller
@RequestMapping("/User")
public class UserController {
	@Resource
	private UserService userService;

	/**
	 * 用户初始页
	 * 
	 * @return
	 */
	@RequestMapping("/index")
	public String toUser() {
		return "system/user";
	}

	/**
	 * 获取用户分页
	 * 
	 * @param request
	 * @param response
	 * @param dg
	 * @return
	 */
	@RequestMapping("/queryList")
	@ResponseBody
	public String queryList(HttpServletRequest request, HttpServletResponse response, PageBean<User> dg, User user) {
		List<User> u = userService.queryAll(dg, user);
		DatatablesViewPage<User> view = new DatatablesViewPage<User>();
		view.setDraw(dg.getDraw());
		view.setData(u);
		view.setRecordsFiltered(userService.getCount(user));
		view.setRecordsTotal(view.getRecordsFiltered());
		return JSONObject.fromObject(view).toString();
	}

	/**
	 * 保存、修改用户
	 * 
	 * @param user
	 * @return
	 */
	@RequestMapping(value = "/save")
	@ResponseBody
	public String save(User user) {
		try {
			this.userService.saveUser(user);
		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage();
		}
		return "";
	}

	/**
	 * 删除用户
	 * 
	 * @param ids
	 * @return
	 */
	@RequestMapping(value = "/delete")
	@ResponseBody
	public String delete(String[] ids) {
		try {
			this.userService.deleteUser(ids);
		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage();
		}
		return "";
	}

	/**
	 * 用户分配角色
	 */
	@RequestMapping(value = "/userRoleSelect")
	@ResponseBody
	public List<Map<String, Object>> userRoleSelectTree(String userid) {
		try {
			return userService.userRoleSelectTree(userid);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * 保存用户角色
	 */
	@RequestMapping(value = "/saveRoleSelect")
	@ResponseBody
	public String saveRoleSelect(HttpServletRequest request) {
		String userid = request.getParameter("userid");
		String ids = request.getParameter("ids");
		try {
			userService.saveRoleSelect(userid, ids);
		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage();
		}
		return "";
	}

	@RequestMapping(value = "/updatePwd")
	@ResponseBody
	public String updatePwd(HttpServletRequest request, String newpass) {
		try {
			User u = (User) request.getSession().getAttribute("user");
			this.userService.udpatePassword(u.getId(), newpass);
		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage();
		}
		return "";
	}
}
