package com.base.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;


public class LoginInterceptor implements HandlerInterceptor{
	private final Logger log = LoggerFactory.getLogger(LoginInterceptor.class);  
	public String[] allowUrls;//还没发现可以直接配置不拦截的资源，所以在代码里面来排除    
    
    public void setAllowUrls(String[] allowUrls) {    
        this.allowUrls = allowUrls;    
    } 
	/**
	 * Handler执行完成之后调用这个方法
	 */
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception exc)
			throws Exception {
		  System.out.println("afterCompletion");
	}

	/**
	 * Handler执行之后，ModelAndView返回之前调用这个方法
	 */
	public void postHandle(HttpServletRequest request, HttpServletResponse response,
			Object handler, ModelAndView modelAndView) throws Exception {
		  System.out.println("postHandle");
	}

	/**
	 * Handler执行之前调用这个方法
	 */
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response,
			Object handler) throws Exception {
		 if ("GET".equalsIgnoreCase(request.getMethod())) {
	            
	        }  
	        log.info("==============执行顺序: 1、preHandle================");    
	        String requestUri = request.getRequestURI();  
	        String contextPath = request.getContextPath();  
	        String url = requestUri.substring(contextPath.length());  
	        
	        log.info("requestUri:"+requestUri);    
	        log.info("contextPath:"+contextPath);    
	        log.info("url:"+url);    
	        
	        if(null != allowUrls && allowUrls.length>=1){    
	            for(String u : allowUrls) {      
	                if(url.contains(u)) {      
	                    return true;
	                }      
	            }  
	        }
	        
	        if(url.indexOf("/login")<0){
	        	String username =  (String)request.getSession().getAttribute("username");   
		        if(username == null){  
		            log.info("Interceptor：跳转到login页面！");  
		            request.getRequestDispatcher("/WEB-INF/view/login.jsp").forward(request, response);  
		            return false;  
		        }else  
		            return true; 
	        }else
	        	return true;
	}

}


