package com.base.tools;

import java.io.File;
import java.util.StringTokenizer;

/**
 * @author Administrator
 *文件 目录类工具
 */
public class FilesUtil {
	 /**
     * 获取文件的后缀名并转化成大写
     * 
     * @param fileName
     *            文件名
     * @return
     */
    public String getFileSuffix(String fileName) throws Exception {
        return fileName.substring(fileName.lastIndexOf(".") + 1,
                fileName.length()).toUpperCase();
    }

    /**
     * 创建多级目录
     * 
     * @param path
     *            目录的绝对路径
     */
    public void createMultilevelDir(String path) {
        try {
            StringTokenizer st = new StringTokenizer(path, "/");
            String path1 = st.nextToken() + "/";
            String path2 = path1;
            while (st.hasMoreTokens()) {

                path1 = st.nextToken() + "/";
                path2 += path1;
                File inbox = new File(path2);
                if (!inbox.exists())
                    inbox.mkdir();

            }
        } catch (Exception e) {
            System.out.println("目录创建失败" + e);
            e.printStackTrace();
        }

    }

    /**
     * 删除文件/目录(递归删除文件/目录)
     * 
     * @param path
     *            文件或文件夹的绝对路径
     */
    public void deleteAll(String dirpath) {
        if (dirpath == null) {
            System.out.println("目录为空");
        } else {
            File path = new File(dirpath);
            try {
                if (!path.exists())
                    return;// 目录不存在退出
                if (path.isFile()) // 如果是文件删除
                {
                    path.delete();
                    return;
                }
                File[] files = path.listFiles();// 如果目录中有文件递归删除文件
                for (int i = 0; i < files.length; i++) {
                    deleteAll(files[i].getAbsolutePath());
                }
                path.delete();

            } catch (Exception e) {
                System.out.println("文件/目录 删除失败" + e);
                e.printStackTrace();
            }
        }
    }

    /**
     * 文件/目录 重命名
     * 
     * @param oldPath
     *            原有路径（绝对路径）
     * @param newPath
     *            更新路径
     */
    public void renameDir(String oldPath, String newPath) {
        File oldFile = new File(oldPath);// 文件或目录
        File newFile = new File(newPath);// 文件或目录
        try {
            boolean success = oldFile.renameTo(newFile);// 重命名
            if (!success) {
                System.out.println("重命名失败");
            } else {
                System.out.println("重命名成功");
            }
        } catch (RuntimeException e) {
            e.printStackTrace();
        }
    }
    
    /** 
     * 新建目录 
     */  
    public static boolean newDir(String path) throws Exception {  
        File file = new File(path);  
        return file.mkdirs();//创建目录   
    }  
      
    /** 
     * 删除目录 
     */  
    public static boolean deleteDir(String path) throws Exception {  
        File file = new File(path);  
        if (!file.exists())  
            return false;// 目录不存在退出   
        if (file.isFile()) // 如果是文件删除   
        {  
            file.delete();  
            return false;  
        }  
        File[] files = file.listFiles();// 如果目录中有文件递归删除文件   
        for (int i = 0; i < files.length; i++) {  
            deleteDir(files[i].getAbsolutePath());  
        }  
        file.delete();  
          
        return file.delete();//删除目录   
    }  
  
    /** 
     * 更新目录 
     */  
    public static boolean updateDir(String path, String newPath) throws Exception {  
        File file = new File(path);  
        File newFile = new File(newPath);  
        return file.renameTo(newFile);  
    }  
      
    // 删除文件夹   
    // param folderPath 文件夹完整绝对路径   
    public static void delFolder(String folderPath) {  
        try {  
            delAllFile(folderPath); // 删除完里面所有内容   
            String filePath = folderPath;  
            filePath = filePath.toString();  
            java.io.File myFilePath = new java.io.File(filePath);  
            myFilePath.delete(); // 删除空文件夹   
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
    }  
  
    // 删除指定文件夹下所有文件   
    // param path 文件夹完整绝对路径   
    public static boolean delAllFile(String path) {  
        boolean flag = false;  
        File file = new File(path);  
        if (!file.exists()) {  
            return flag;  
        }  
        if (!file.isDirectory()) {  
            return flag;  
        }  
        String[] tempList = file.list();  
        File temp = null;  
        for (int i = 0; i < tempList.length; i++) {  
            if (path.endsWith(File.separator)) {  
                temp = new File(path + tempList[i]);  
            } else {  
                temp = new File(path + File.separator + tempList[i]);  
            }  
            if (temp.isFile()) {  
                temp.delete();  
            }  
            if (temp.isDirectory()) {  
                delAllFile(path + "/" + tempList[i]);// 先删除文件夹里面的文件   
                delFolder(path + "/" + tempList[i]);// 再删除空文件夹   
                flag = true;  
            }  
        }  
        return flag;  
    }  

}
