package com.base.tools;

import java.util.List;

/**
 * @author Administrator datatbales返回页面对象
 * @param <T>
 */
public class DatatablesViewPage<T> {

	private Integer draw;
	private Integer recordsTotal;
	private Integer recordsFiltered;
	private List<T> data; // data加载的“dataSrc"对应

	public Integer getDraw() {
		return draw;
	}

	public void setDraw(Integer draw) {
		this.draw = draw;
	}

	public Integer getRecordsTotal() {
		return recordsTotal;
	}

	public void setRecordsTotal(Integer recordsTotal) {
		this.recordsTotal = recordsTotal;
	}

	public Integer getRecordsFiltered() {
		return recordsFiltered;
	}

	public void setRecordsFiltered(Integer recordsFiltered) {
		this.recordsFiltered = recordsFiltered;
	}

	public List<T> getData() {
		return data;
	}

	public void setData(List<T> data) {
		this.data = data;
	}

}
