package com.base.tools;

import java.util.List;

/**
 * @author Administrator
 *分页bean工具
 * @param <T>
 */
public class PageBean<T> {

	  private Integer pageNumber; //当前页数
	    private Integer pageSize;   //一页显示数量
	    private Integer startRow;   //查询起始行
	    private Integer total;      //总记录行数
	    private List<T> rows;       //查询结果数据
	    private T queryObj;         //查询对象
	    private Integer draw; //datatables请求次数计数器,每次发送给服务器后原封返回
	    private String column; //datatables 排序字段
	    private String dir; //datatables 排序类型 asc desc
	    

	    public String getColumn() {
			return column;
		}

		public void setColumn(String column) {
			this.column = column;
		}

		public String getDir() {
			return dir;
		}

		public void setDir(String dir) {
			this.dir = dir;
		}

		public Integer getDraw() {
			return draw;
		}

		public void setDraw(Integer draw) {
			this.draw = draw;
		}

		public Integer getStartRow() {
	       return startRow;
	    }

	    public Integer getPageNumber() {
	        return pageNumber;
	    }

	    public void setPageNumber(Integer pageNumber) {
	        this.pageNumber = pageNumber;
	    }

	    public Integer getPageSize() {
	        return pageSize;
	    }

	    public void setPageSize(Integer pageSize) {
	        this.pageSize = pageSize;
	    }

	    public Integer getTotal() {
	        return total;
	    }

	    public void setStartRow(Integer startRow) {
	        this.startRow = startRow;
	    }

	    public void setTotal(Integer total) {
	        this.total = total;
	    }

	    public List<T> getRows() {
	        return rows;
	    }

	    public void setRows(List<T> rows) {
	        this.rows = rows;
	    }

	    public void setQueryObj(T queryObj) {
	        this.queryObj = queryObj;
	    }

	    public T getQueryObj() {
	        return queryObj;
	    }

}
