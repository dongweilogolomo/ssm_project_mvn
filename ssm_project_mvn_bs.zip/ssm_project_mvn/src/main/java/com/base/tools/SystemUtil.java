package com.base.tools;

/**
 * @author Administrator
 *系统类工具
 */
public class SystemUtil {
	
	
	/**
	 * 获取当前系统类型
	 * @return
	 */
	public static String getOSName() {
		String os = System.getProperty("os.name");
		if (os.toLowerCase().startsWith("win")) {
			return "Windows";
		} else if (os.toLowerCase().startsWith("lin")) {
			return "Linux";
		}
		return null;
	}

}

