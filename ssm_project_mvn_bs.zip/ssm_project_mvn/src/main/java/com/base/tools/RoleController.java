package com.system.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.base.tools.PageBean;
import com.system.domain.Role;
import com.system.service.RoleService;

import net.sf.json.JSONObject;

@Controller
@RequestMapping("/Role")
public class RoleController {
	@Resource
	private RoleService roleService;
	
	/**
	 * 跳转至角色管理页面
	 * @return
	 */
	@RequestMapping(value = "/index")
	public String index() {
		return "/system/role";
	}
	
	/**
	 * 角色列表查询
	 */
	@RequestMapping("/queryList")
	@ResponseBody
	public String queryList(HttpServletRequest request, HttpServletResponse response, PageBean<Role> dg,Role role) {
		dg.setPageNumber(Integer.parseInt(request.getParameter("page")));
		dg.setPageSize(Integer.parseInt(request.getParameter("rows")));
		dg.setStartRow((dg.getPageNumber() - 1) * dg.getPageSize());
		List<Role> r = this.roleService.queryRoleByPage(dg,role);
		dg.setTotal(this.roleService.getCount());
		dg.setRows(r);
		return JSONObject.fromObject(dg).toString();
	}
	
	/**
	 * 编辑角色
	 * @param request
	 * @param response
	 * @param cont
	 * @return
	 */
	@RequestMapping(value = "/save")
	@ResponseBody
	public String save(Role role) {
		try {
			this.roleService.saveRole(role);
		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage();
		}
		return "";
	}
	
	/**
	 * 删除角色
	 * @param request
	 * @param response
	 * @param ids
	 * @return
	 */
	@RequestMapping(value = "/delete")
	@ResponseBody
	public String delete(String ids) {
		try {
			this.roleService.deleteRole(ids);
		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage();
		}
		return "";
	}
	
	/**
	 * 角色分配菜单树
	 */
	@RequestMapping(value = "/roleMenuSelect")
	@ResponseBody
	public List<Map<String, Object>> roleMenuSelect(String roleid) {
		try {
			return roleService.roleMenuSelectTree(roleid);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 保存角色的菜单
	 */
	@RequestMapping(value = "/saveMenuSelect")
	@ResponseBody
	public String saveMenuSelect(HttpServletRequest request) {
		String roleid = request.getParameter("roleid");
		String ids = request.getParameter("ids");
		try {
			roleService.saveMenuSelect(roleid,ids);
		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage();
		}
		return "";
	}
	
}
